def get_feature_set(name: str):
    if name == "clinical":
        return [
            'age', 'age_category', 'sex', 'residence', 'overcrowding', 'bmi',
            'underweight', 'hiv_status', 'previous_tb', 'smear_status',
            'culture_confirmed', 'mdr_tb', 'xdr_tb',
            'symptom_duration_weeks', 'cough', 'fever', 'night_sweats',
            'weight_loss', 'hemoptysis', 'chest_pain', 'fatigue',
            'esr_mm_hr', 'hemoglobin_g_dl', 'anemia'
        ]

    if name == "radiological":
        return [
            "xray_abnormal",
            "xray_findings",
            "cavitary_disease"
        ]

    if name == "all":
        return None