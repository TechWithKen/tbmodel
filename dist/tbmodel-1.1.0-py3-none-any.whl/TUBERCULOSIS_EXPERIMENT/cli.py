import argparse

from TUBERCULOSIS_EXPERIMENT.main import (
    run_training_pipeline
)


def main():
    import argparse

    parser = argparse.ArgumentParser()

    parser.add_argument("command")

    args = parser.parse_args()

    if args.command == "train":
        run_training_pipeline("all")

    elif args.command == "clinical-train":
        run_training_pipeline("clinical")

    elif args.command == "radiological-train":
        run_training_pipeline("radiological")